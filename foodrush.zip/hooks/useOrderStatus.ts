"use client";

import { useEffect } from "react";
import { toast } from "sonner";

import { useOrderStore } from "@/store/orderStore";

interface SSEPayload {
  status: "Order Received" | "Preparing" | "Out for Delivery" | "Delivered";
  updatedAt: string;
}

export const useOrderStatus = (orderId: string, enabled: boolean) => {
  const { orders, updateOrderStatus } = useOrderStore();

  useEffect(() => {
    if (!orderId || !enabled) {
      return undefined;
    }

    const source = new EventSource(`/api/orders/${orderId}/status-stream`);
    source.onmessage = (event) => {
      try {
        const payload = JSON.parse(event.data) as SSEPayload;
        updateOrderStatus(orderId, payload.status, payload.updatedAt);
        toast.message(`Order update: ${payload.status}`);
        if (payload.status === "Delivered") {
          source.close();
        }
      } catch (_error) {
        toast.error("Failed to process live status update.");
      }
    };

    source.onerror = () => {
      source.close();
    };

    return () => {
      source.close();
    };
  }, [orderId, enabled, updateOrderStatus]);

  return orders[orderId];
};
