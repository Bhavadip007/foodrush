"use client";

import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";

import { MenuItem } from "@/lib/db/types";

export interface CartLine {
  menuItem: MenuItem;
  quantity: number;
}

interface CartState {
  items: CartLine[];
  isOpen: boolean;
  recentActionStamp: number;
  openCart: () => void;
  closeCart: () => void;
  toggleCart: () => void;
  addItem: (menuItem: MenuItem) => void;
  decrementItem: (menuItemId: string) => void;
  incrementItem: (menuItemId: string) => void;
  removeItem: (menuItemId: string) => void;
  clearCart: () => void;
}

export const useCartStore = create<CartState>()(
  persist(
    (set) => ({
      items: [],
      isOpen: false,
      recentActionStamp: Date.now(),
      openCart: () => set({ isOpen: true }),
      closeCart: () => set({ isOpen: false }),
      toggleCart: () => set((state) => ({ isOpen: !state.isOpen })),
      addItem: (menuItem) =>
        set((state) => {
          const existing = state.items.find((item) => item.menuItem.id === menuItem.id);
          if (!existing) {
            return {
              items: [...state.items, { menuItem, quantity: 1 }],
              recentActionStamp: Date.now(),
            };
          }

          return {
            items: state.items.map((item) =>
              item.menuItem.id === menuItem.id ? { ...item, quantity: item.quantity + 1 } : item,
            ),
            recentActionStamp: Date.now(),
          };
        }),
      decrementItem: (menuItemId) =>
        set((state) => ({
          items: state.items
            .map((item) =>
              item.menuItem.id === menuItemId ? { ...item, quantity: item.quantity - 1 } : item,
            )
            .filter((item) => item.quantity > 0),
          recentActionStamp: Date.now(),
        })),
      incrementItem: (menuItemId) =>
        set((state) => ({
          items: state.items.map((item) =>
            item.menuItem.id === menuItemId ? { ...item, quantity: item.quantity + 1 } : item,
          ),
          recentActionStamp: Date.now(),
        })),
      removeItem: (menuItemId) =>
        set((state) => ({
          items: state.items.filter((item) => item.menuItem.id !== menuItemId),
          recentActionStamp: Date.now(),
        })),
      clearCart: () => set({ items: [], recentActionStamp: Date.now() }),
    }),
    {
      name: "foodrush-cart",
      storage: createJSONStorage(() => localStorage),
      partialize: (state) => ({ items: state.items }),
    },
  ),
);
